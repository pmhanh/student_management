import { Test, TestingModule } from '@nestjs/testing';
import { StudentService } from './student.service';
import { getModelToken, MongooseModule } from '@nestjs/mongoose';
import { Student, StudentSchema } from './schema/student.schema'; 
import { Model } from 'mongoose';

// jest.mock('../logger', () => ({
//     logInfo: jest.fn(), // Mock hàm logInfo
//   }));
const mockStudent = {
    studentId: '123456',
    fullName: 'John Doe',
    birthDate: new Date('2000-01-01'),
    gender: 'Nam',
    faculty: 'Khoa luật',
    course: '2025',
    program: 'CLC',
    email: 'john.doe@example.com',
    phone: '0123456789',
    status: 'Đang học',
  };
const mockStudentModel = {
    new: jest.fn().mockResolvedValue(mockStudent),
    constructor: jest.fn().mockResolvedValue(mockStudent),
    find: jest.fn(),
    findOne: jest.fn(),
    save: jest.fn(),
    exec: jest.fn(),
    logInfo: jest.fn(),
};
describe('StudentService', () => {
    let service: StudentService;
    let model: Model<Student>;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [
                MongooseModule.forFeature([{name: Student.name, schema: StudentSchema}]),

            ],
            providers: [
                StudentService,
                { provide: getModelToken(Student.name), useValue: mockStudentModel },
            ],
        }).compile();

        service = module.get<StudentService>(StudentService);
        model = module.get<Model<Student>>(getModelToken(Student.name));
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    // describe('createStudent', () => {
    //     it('should create a new student', async () => {
    //         const studentData = { mockStudent };
    //         // jest.spyOn(model.prototype, 'save').mockResolvedValueOnce(studentData as any);
    //         const result = await service.createStudent(studentData);
    //         expect(result).toEqual(studentData);
    //     });
    // });

    // describe('getStudentById', () => {
    //     it('should return a student by ID', async () => {
    //         const studentId = '123456';
    //         const studentData = { mockStudent };
    //         jest.spyOn(model, 'findOne').mockReturnValue({
    //             exec: jest.fn().mockResolvedValueOnce(studentData),
    //         } as any);
    //         const result = await service.getStudentById(studentId);
    //         expect(result).toEqual(studentData);
    //     });
    // });
});