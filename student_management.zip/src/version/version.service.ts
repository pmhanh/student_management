import { Get, Injectable } from '@nestjs/common';
import * as packageJson from 'package.json';

@Injectable()
export class VersionService {
    getVersionInfo() {
        return {
            version: packageJson.version,
            buildDate: packageJson.buildDate,
        };
    }
}
